using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace NodeAI
{
    public class GoTo : ActionBase
    {
        NavMeshAgent navAgent;
        public GoTo()
        {
            AddProperty<Transform>("Position", null);
            AddProperty<float>("Stopping distance", 0.5f);
            AddProperty<float>("Speed", 1);
            AddProperty<float>("Acceleration", 15);
            AddProperty<bool>("Interrupt", false);
        }
        public override void OnInit()
        {
            SetProperty<bool>("Interrupt", false);
        }
        public override NodeData.State Eval(NodeAI_Agent agent, NodeTree.Leaf current)
        {
            if(navAgent == null)
            {
                navAgent = agent.GetComponent<NavMeshAgent>();
                if(navAgent == null)
                {
                    Debug.LogError("No NavMeshAgent found on " + agent.gameObject.name);
                    state = NodeData.State.Failure;
                    return NodeData.State.Failure;
                }
            }
            if(GetProperty<bool>("Interrupt"))
            {
                navAgent.isStopped = true;
                state = NodeData.State.Failure;
                return NodeData.State.Failure;
            }
            if(navAgent.isOnNavMesh && GetProperty<Transform>("Position"))
            {
                if(GetProperty<float>("Stopping distance") > 0)
                {
                    navAgent.stoppingDistance = GetProperty<float>("Stopping distance");
                }
                //navAgent.SetDestination(GetProperty<Transform>("Position").position);
                NavMeshHit nhit;
                NavMesh.SamplePosition(GetProperty<Transform>("Position").position, out nhit, 4.0f, NavMesh.AllAreas);
                if(Vector3.Distance(agent.transform.position, GetProperty<Transform>("Position").position) <= navAgent.stoppingDistance + 0.01f)
                {
                    navAgent.isStopped = true;
                    state = NodeData.State.Success;
                    return NodeData.State.Success;
                }
                
                if(navAgent.SetDestination(nhit.position))
                {
                    
                    navAgent.isStopped = false;
                    navAgent.speed = GetProperty<float>("Speed");
                    navAgent.acceleration = GetProperty<float>("Acceleration");
                    
                    state = NodeData.State.Running;
                    return NodeData.State.Running;
                }
                else
                {
                    navAgent.isStopped = true;
                    Debug.LogError("Could not set destination to " + GetProperty<Transform>("Position").position);
                    state = NodeData.State.Failure;
                    return NodeData.State.Failure;
                }
            }
            else
            {
                Debug.Log("No NavMeshAgent found on " + agent.gameObject.name);
                state = NodeData.State.Failure;
                return NodeData.State.Failure;
            }
        }
    }
}
